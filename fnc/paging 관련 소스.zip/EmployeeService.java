package com.siwan.ems.web.employee.service;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.siwan.ems.common.util.DateUtil;
import com.siwan.ems.common.util.ExcelFileUtil;
import com.siwan.ems.common.util.MessageUtil;
import com.siwan.ems.web.code.mapper.CodeMapper;
import com.siwan.ems.web.employee.mapper.EmployeeMapper;
import com.siwan.ems.web.employee.vo.EmployeeVO;
import com.siwan.ems.web.login.vo.SessionVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeMapper employeeMapper;
	
	@Autowired
	private CodeMapper codeMapper;
	
	/**
	 * 목록 검색
	 * @param paramVO
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> employee_0101(EmployeeVO paramVO) throws Exception {
		log.debug("========== EmployeeService.employee_0101 ==========");
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		// 검색
		int cnt = employeeMapper.getEmployeeListCnt(paramVO);
		
		List<EmployeeVO> employeeList = employeeMapper.getEmployeeList(paramVO);
		
		resultMap.put("cnt", cnt);
		resultMap.put("employeeList", employeeList);
		
		return resultMap;
	}
	
	/**
	 * 엑셀 다운로드
	 * @param paramVO
	 * @return
	 * @throws Exception
	 */
	public void employee_0102(EmployeeVO paramVO, HttpServletResponse response) throws Exception {
		log.debug("========== EmployeeService.employee_0102 ==========");
		
		try{
			String fileNm = "직원관리_" + DateUtil.getDateTimeString(); // 파일명
			String[] columnArr = {"NO", "직원번호", "직원명", "직급", "고용방식"}; // 헤더명
			String[] rowArr = {"", "EMP_NO", "EMP_NM", "POSITION_NM", "EMPLOYMENT_METHOD_NM"}; // 행명
			
            // Excel Down 시작
            Workbook workbook = new HSSFWorkbook();
            
            // 시트생성
            Sheet sheet = workbook.createSheet("직원관리"); // 시트명
            
            // 행번호
            int rowNo = 0;
            
            // 헤더 구성
            rowNo = ExcelFileUtil.setExcelHeader(workbook, sheet, rowNo, columnArr);
            
            // 직원 엑셀 목록
            List<Map<String, Object>> employeeList = employeeMapper.getEmployeeListExcel(paramVO);
            
            // 행 구성
            ExcelFileUtil.setExcelRow(workbook, sheet, rowNo, rowArr, employeeList);
            
            // 컨텐츠 타입과 파일명 지정
            response.setHeader("Content-Type", "application/octet-stream; charset=utf-8");
            response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileNm, "utf-8") + ".xls");
            
            // 엑셀 출력
            workbook.write(response.getOutputStream());
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 등록
	 * @param paramVO
	 * @return
	 * @throws Exception
	 */
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public Map<String, Object> employee_0201(EmployeeVO paramVO, HttpServletRequest request) throws Exception {
		log.debug("==========  EmployeeService.employee_0201 ==========");
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		SessionVO sessionVO = (SessionVO)request.getSession().getAttribute("sessionVO");
		
		String resultCd = "FAIL";
		String resultMsg = MessageUtil.getMessage("insert.fail");
		
		// 등록
		paramVO.setRegUserId(sessionVO.getUserId());
		paramVO.setModUserId(sessionVO.getUserId());
		
		int resultCnt = (int)employeeMapper.insertEmployee(paramVO);
		
		if(resultCnt > 0) {
			resultCd = "SUCCESS";
			resultMsg = MessageUtil.getMessage("insert.success");
		}
		
		resultMap.put("resultCd", resultCd);
		resultMap.put("resultMsg", resultMsg);
		
		return resultMap;
	}
	
	/**
	 * 수정화면 이동
	 * @param empNo
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> employee_0300(String empNo) throws Exception {
		log.debug("========== EmployeeService.employee_0300 ==========");
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		// 검색
		EmployeeVO employeeVO = new EmployeeVO();
		employeeVO.setEmpNo(empNo);
		
		EmployeeVO employeeInfo = employeeMapper.getEmployeeInfo(employeeVO);
		
		resultMap.put("employeeInfo", employeeInfo);
		
		return resultMap;
	}
	
	/**
	 * 수정
	 * @param paramVO
	 * @return
	 * @throws Exception
	 */
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public Map<String, Object> employee_0301(EmployeeVO paramVO, HttpServletRequest request) throws Exception {
		log.debug("========== EmployeeService.employee_0301 ==========");
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		SessionVO sessionVO = (SessionVO)request.getSession().getAttribute("sessionVO");
		
		String resultCd = "FAIL";
		String resultMsg = MessageUtil.getMessage("update.fail");
		
		// 수정
		paramVO.setModUserId(sessionVO.getUserId());
		
		int resultCnt = (int)employeeMapper.updateEmployee(paramVO);
		
		if(resultCnt > 0) {
			resultCd = "SUCCESS";
			resultMsg = MessageUtil.getMessage("update.success");
		}
		
		resultMap.put("resultCd", resultCd);
		resultMap.put("resultMsg", resultMsg);
		
		return resultMap;
	}
	
	/**
	 * 삭제
	 * @param paramVO
	 * @return
	 * @throws Exception
	 */
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public Map<String, Object> employee_0302(EmployeeVO paramVO, HttpServletRequest request) throws Exception {
		log.debug("========== EmployeeService.employee_0302 ==========");
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		SessionVO sessionVO = (SessionVO)request.getSession().getAttribute("sessionVO");
		
		String resultCd = "FAIL";
		String resultMsg = MessageUtil.getMessage("delete.fail");
		
		// 삭제
		paramVO.setModUserId(sessionVO.getUserId());
		
		int resultCnt = (int)employeeMapper.deleteEmployee(paramVO);
		
		if(resultCnt > 0) {
			resultCd = "SUCCESS";
			resultMsg = MessageUtil.getMessage("delete.success");
		}
		
		resultMap.put("resultCd", resultCd);
		resultMap.put("resultMsg", resultMsg);
		
		return resultMap;
	}
}
