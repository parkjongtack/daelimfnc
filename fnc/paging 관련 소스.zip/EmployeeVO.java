package com.siwan.ems.web.employee.vo;

import lombok.Data;

@Data
public class EmployeeVO {
	
	private String empNo;
    private String empNm;
    private String position;
    private String positionNm;
    private String employmentMethod;
    private String employmentMethodNm;
    private String regUserId;
    private String modUserId;
    
    private String searchEmpNo;
    private String searchEmpNm;
    private String searchPosition;
    private String searchEmploymentMethod;
	
	private String sNum;
	private String eNum;
}
